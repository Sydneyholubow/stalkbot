stalk.pl
========

 Reads a JSON file of websites and keywords and loads each webpage and sends an alert if none of the keyphrases are found.

 stalk was developed as an agent to stalk websites waiting for out of stock merchandise to become available and to send a text message alert when a given item is available for purchase.
